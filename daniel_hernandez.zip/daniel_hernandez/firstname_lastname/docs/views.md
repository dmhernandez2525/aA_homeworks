# View Wireframes

## ReportIndex

![alt tag][report_index]

## ReportShow

![alt tag][report_show]

## ReportForm

### When Creating New Report

![alt tag][report_form_when_adding]

### When Updating Report

![alt tag][report_form_when_updating]

[report_index]: ./wireframes/report_index.png
[report_show]: ./wireframes/report_show.png
[report_form_when_adding]: ./wireframes/report_form_when_adding.png
[report_form_when_updating]: ./wireframes/report_form_when_updating.png
