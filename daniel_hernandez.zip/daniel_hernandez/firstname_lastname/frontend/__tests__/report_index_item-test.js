/* globals jest */

import React from 'react';
import { Link, Route } from 'react-router-dom';
import { shallow, mount } from 'enzyme';
import MockRouter from 'react-mock-router';

import ReportIndexItem from '../components/reports/report_index_item';
import { formatDate } from '../util/date_util';

const mockedReport = {
  id: 1,
  understanding: 'good',
  improvement: 'great',
  createdAt: '2017-02-17T04:19:07.404Z',
  updatedAt: '2017-02-17T04:19:07.404Z'
};

describe('ReportIndexItem', () => {
  let report,
      reportIndexNode,
      push,
      deleteReport;

  beforeEach(() => {
    report = mockedReport;
    deleteReport = jest.fn();
    push = jest.fn();

    const testProps = {
      deleteReport,
      report
    };

    reportIndexNode = mount(
      <MockRouter push={push}>
        <ReportIndexItem {...testProps} />
      </MockRouter>
    ).find('ReportIndexItem');
  });

  it('should be a function', () => {
    expect(typeof ReportIndexItem).toEqual('function');
  });

  it('shows the report\'s date as a Link to the report\'s show page', () => {
    const showLink = reportIndexNode.find("Link").filterWhere(link => (
     /reports(?!.*edit)/i.test(link.props().to)
    ));
    const expectedText = formatDate(report.createdAt);

    expect(showLink.node.props.children).toEqual(expectedText);
  });

  it('has a link that links to the report edit page', () => {
    const editLink = reportIndexNode.find('Link').filterWhere(link => (
      /edit/i.test(link.props().to)
    ));
    
    expect(editLink.props().children).toEqual('Edit');
  });

  it('has a button to delete report', () => {
    const deleteButton = reportIndexNode.find('button').filterWhere(button => (
      /delete/i.test(button.props().children)
    ));
    expect(deleteButton).toBeDefined();

    // click on Delete button with mock report object
    deleteButton.simulate('click');
    expect(deleteReport).toBeCalledWith(report.id);
  });
});
