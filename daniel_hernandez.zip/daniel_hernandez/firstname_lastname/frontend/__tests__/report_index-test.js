/* globals jest */

import React from 'react';
import { shallow } from 'enzyme';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore } from 'redux';

import ReportIndexContainer from '../components/reports/report_index_container';
import ReportIndexItem from '../components/reports/report_index_item';

const reports = [{
  id: 1,
  understanding: 'good',
  improvement: 'great',
  createdAt: '2017-02-17T04:19:07.404Z',
  updatedAt: '2017-02-17T04:19:07.404Z'
}, {
  id: 2,
  understanding: 'great',
  improvement: 'good',
  createdAt: '2017-02-18T04:19:07.404Z',
  updatedAt: '2017-02-18T04:19:07.404Z'
}, {
  id: 3,
  understanding: 'great',
  improvement: 'great',
  createdAt: '2017-02-19T04:19:07.404Z',
  updatedAt: '2017-02-19T04:19:07.404Z'
}];

const testReducer = (oldState, action) => ({ reports });
const testStore = createStore(testReducer);

describe('ReportIndex', () => {
  let reportIndexNode;

  beforeEach(() => {
    // Shallow renders allow us to unit test only the highest level
    // component (i.e. test ReportIndex independently of ReportIndexItem)
    reportIndexNode = shallow(<ReportIndexContainer store={testStore} params={reports} />).shallow();
  });

  it('renders a ReportIndexItem for each report, passing in each report as a "report" prop', () => {
    const reportIndexItems = reportIndexNode.find(ReportIndexItem).nodes;
    expect(reportIndexItems.length).toBe(3);

    // tests that each ReportIndexItem has correct props
    for (let i = 0; i < reportIndexItems.length; i += 1) {
      expect(reportIndexItems[i].props.report).toBe(reports[i]);
    }
  });

  it('Links to the ReportForm page', () => {
    const newLink = reportIndexNode.find('Link');

    expect(newLink.node.props.to).toEqual(`/reports/new`);
  });
});
