/* globals jest */

import React from 'react';
import ReactDOM from 'react-dom';
import configureMockStore from 'redux-mock-store';
import { createStore, applyMiddleware  } from 'redux';
import thunk from 'redux-thunk';
import { mount } from 'enzyme';
import MockRouter from 'react-mock-router';
import { Route } from 'react-router-dom';

import CreateReportFormContainer from '../components/reports/create_report_form_container';
import EditReportFormContainer from '../components/reports/edit_report_form_container';
import * as ReportActions from '../actions/report_actions';

const mockedReport = {
  id: 1,
  understanding: 'good',
  improvement: 'great',
  created_at: '2017-02-17T04:19:07.404Z',
  updated_at: '2017-02-17T04:19:07.404Z'
};

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
const testStore = mockStore({ reports: { [mockedReport.id]: mockedReport } });

describe('ReportFormContainer', () => {
  let reportFormWrapper,
      understandingInput,
      improvementTextarea;

  beforeEach(() => {
    ReportActions.updateReport = jest.fn(report => dispatch => (
      Promise.resolve(mockedReport)
    ));
    ReportActions.requestReport = jest.fn(id => dispatch => (
      Promise.resolve(mockedReport)
    ));
    ReportActions.createReport = jest.fn(report => dispatch => (
      Promise.resolve(mockedReport)
    ));
  });

  describe('creating a new report', () => {
    beforeEach(() => {
      reportFormWrapper = mount(
        <MockRouter path={'/'}>
          <Route render={(props) => (
            <CreateReportFormContainer store={testStore} {...props} />
          )} />
        </MockRouter>
      ).find('ReportForm');

      understandingInput = reportFormWrapper.find('input').filterWhere(input => (
        input.props().type === 'text'
      ));

      improvementTextarea = reportFormWrapper.find('textarea');
    });

    it('correctly maps state to props', () => {
      expect(reportFormWrapper.props().report).toEqual({
        understanding: '',
        improvement: ''
      });
    });

    it('correctly maps dispatch to props', () => {
      const props = reportFormWrapper.props();

      expect(props.requestReport).toBeUndefined();
      expect(props.action).toBeDefined();
    });

    it('pre-fills understanding input field with an empty string', () => {
      expect(understandingInput.props().value).toEqual('');
    });

    it('pre-fills improvement textarea field with an empty string', () => {
      expect(improvementTextarea.props().value).toEqual('');
    });

    it('updates the understanding input field when it changes', () => {
      const value = 'I\'m doing OK.';
      understandingInput.simulate('change', { target: { value } });
      expect(understandingInput.props().value).toEqual(value);
    });

    it('updates the improvement textarea when it changes', () => {
      const value = 'I can do better!';
      improvementTextarea.simulate('change', { target: { value } });
      expect(improvementTextarea.props().value).toEqual(value);
    });

    it('triggers the correct action when submitted', () => {
      const newReport = { understanding: 'I get it.', improvement: 'I can do better.' };
      understandingInput.simulate('change', { target: { value: newReport.understanding }});
      improvementTextarea.simulate('change', { target: { value: newReport.improvement }});
      reportFormWrapper.find('form').simulate('submit');

      expect(ReportActions.createReport).toBeCalledWith(newReport);
    });
  });

  describe('updating an existing report', () => {
    beforeEach(() => {
      const testParams = { reportId: mockedReport.id };
      const editPath = `/reports/${mockedReport.id}/edit`;
      reportFormWrapper = mount(
        <MockRouter path={editPath} params={testParams}>
          <Route render={(props) => (
            <EditReportFormContainer store={testStore} {...props} />
          )} />
        </MockRouter>
      ).find('ReportForm');

      understandingInput = reportFormWrapper.find('input').filterWhere(input => (
        input.props().type === 'text'
      ));

      improvementTextarea = reportFormWrapper.find('textarea');
    });

    it('correctly maps state to props', () => {
      expect(reportFormWrapper.props().report).toEqual(mockedReport);
    });

    it('correctly maps dispatch to props', () => {
      const props = reportFormWrapper.props();

      expect(props.requestReport).toBeUndefined();
      // Hint: fetch in EditReportForm!
      expect(props.action).toBeDefined();
    });

    it('pre-fills understanding input field that of the correct report', () => {
      expect(understandingInput.props().value).toEqual(mockedReport.understanding);
    });

    it('pre-fills improvement textarea field with that of the correct report', () => {
      expect(improvementTextarea.props().value).toEqual(mockedReport.improvement);
    });

    it('updates the understanding input field when it changes', () => {
      const value = 'I\'m doing OK.';
      understandingInput.simulate('change', { target: { value } });
      expect(understandingInput.props().value).toEqual(value);
    });

    it('updates the improvement textarea when it changes', () => {
      const value = 'I can do better!';
      improvementTextarea.simulate('change', { target: { value } });
      expect(improvementTextarea.props().value).toEqual(value);
    });

    it('triggers the correct action when submitted', () => {
      reportFormWrapper.find('form').simulate('submit');
      expect(ReportActions.updateReport).toBeCalledWith(mockedReport);
    });
  });
});
