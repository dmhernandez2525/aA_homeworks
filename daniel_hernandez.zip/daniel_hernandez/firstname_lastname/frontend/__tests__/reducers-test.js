/* globals jest */

import ReportsReducer from '../reducers/reports_reducer';
import RootReducer from '../reducers/root_reducer';
import { createStore } from 'redux';

describe('Reducers', () => {
  describe('ReportsReducer', () => {
    it('exports a function', () => {
      expect(typeof ReportsReducer).toEqual('function');
    });

    it('should initialize with an empty object as the default state', () => {
      expect(ReportsReducer(undefined, {})).toEqual({});
    });

    it('should return the previous state if an action is not matched', () => {
      const oldState = { 1: 'oldState' };
      const newState = ReportsReducer(oldState, { type: 'notAType' });
      expect(newState).toEqual(oldState);
    });

    describe('handling the RECEIVE_REPORTS action', () => {
      let testReports,
          action;

      beforeEach(() => {
        testReports = { 1: 'testReport1', 2: 'testReport2' };
        action = {
          type: 'RECEIVE_REPORTS',
          reports: testReports,
        };
      });

      it('should replace the state with the action\'s reports', () => {
        const state = ReportsReducer(undefined, action);
        expect(state).toEqual(testReports);
      });

      it('should not modify the old state', () => {
        let oldState = { 1: 'oldState' };
        ReportsReducer(oldState, action);
        expect(oldState).toEqual({ 1: 'oldState' });
      });
    });

    describe('handling the RECEIVE_REPORT action', () => {
      let testReport,
          action;

      beforeEach(() => {
        testReport = {
          id: 1,
          understanding: 'good',
          improvement: 'great',
          created_at: '2017-02-17T04:19:07.404Z',
          updated_at: '2017-02-17T04:19:07.404Z',
        };
        action = {
          type: 'RECEIVE_REPORT',
          report: testReport,
        };
      });

      it('should add the event to the state using the report id as a key', () => {
        let state = ReportsReducer(undefined, action);
        expect(state[1]).toEqual(testReport);
      });

      it('should not affect the other reports in the state', () => {
        let oldState = { 2: 'oldState' };
        let state = ReportsReducer(oldState, action);
        expect(state[2]).toEqual('oldState');
      });
    });

    describe('handling the REMOVE_REPORT action', () => {
      let testReport,
          action;

      beforeEach(() => {
        testReport = {
          id: 1,
          understanding: 'good',
          improvement: 'great',
          created_at: '2017-02-17T04:19:07.404Z',
          updated_at: '2017-02-17T04:19:07.404Z',
        };
        action = {
          type: 'REMOVE_REPORT',
          reportId: testReport.id,
        };
      });

      it('should remove the correct report from the state', () => {
        let state = ReportsReducer({ 1: testReport }, action);
        expect(typeof state[1]).toEqual('undefined');
      });

      it('should not affect the other reports in the state', () => {
        let oldState = { 1: testReport, 2: 'oldState' };
        let state = ReportsReducer(oldState, action);
        expect(state[2]).toEqual('oldState');
      });
    });
  });

  describe('RootReducer', () => {
    let testStore;

    beforeAll(() => {
      testStore = createStore(RootReducer);
    });

    it('exports a function', () => {
      expect(typeof RootReducer).toEqual('function');
    });

    it('includes the ReportsReducer under the key `reports`', () => {
      const report = {
        id: 1,
        understanding: 'good',
        improvement: 'great',
        created_at: '2017-02-17T04:19:07.404Z',
        updated_at: '2017-02-17T04:19:07.404Z',
      };
      const action = { type: 'RECEIVE_REPORT', report };

      testStore.dispatch(action);
      expect(testStore.getState().reports).toEqual(
        ReportsReducer({ [report.id]: report }, report)
      );
    });
  });
});
