import React from 'react';
import { Route } from 'react-router-dom';
import { shallow, mount } from 'enzyme';
import merge from 'lodash/merge';
import MockRouter from 'react-mock-router';

import ReportShow from '../components/reports/report_show';
import {
  formatDate,
  formatTime,
  formatDateTime
} from '../util/date_util';

const mockedReport = {
  id: 1,
  understanding: 'good',
  improvement: 'great',
  createdAt: '2017-02-17T04:19:07.404Z',
  updatedAt: '2017-02-17T04:19:07.404Z'
};

describe('ReportShow', () => {
  let report,
      push,
      requestReport,
      reportShowNode;

  beforeEach(() => {
    report = mockedReport;

    push = jest.fn();
    requestReport = jest.fn(() => dispatch => {});

    const testProps = {
      requestReport,
      report
    };

    push = jest.fn();

    const testPath = `/reports/${mockedReport.id}`;

    reportShowNode = mount(
      <MockRouter push={push} path={testPath}>
        <Route render={(props) => (
          <ReportShow {...props} {...testProps} />
        )} />
      </MockRouter>
    ).find('ReportShow');
  });

  // Use `formatDate` to display `createdAt`.
  it('contains the report createdAt in the `formatDate` format a single time', () => {
    const renderedText = reportShowNode.text();
    const formattedDate = formatDate(report.createdAt);

    expect(renderedText).toContain(formattedDate);
  });

  // Use `formatTime` to display `createdAt`.
  it('contains the report createdAt in the `formatTime` format a single time', () => {
    const renderedText = reportShowNode.text();
    const formattedTime = formatTime(report.createdAt);

    expect(renderedText).toContain(formattedTime);
  });

  // Use `formatDateTime` to display `updatedAt` if, and only if,
  // `updatedAt` is not the same as `createdAt`.
  describe('when the report\'s updatedAt value is not equal to it\'s createdAt value', () => {
    it('contains the report\'s updatedAt value in the proper format', () => {
      const updatedReport = merge({}, report);
      const now = new Date();
      updatedReport.updatedAt = now.toJSON();
      const updatedReportShowNode = shallow(<ReportShow report={updatedReport} />);
      const renderedText = updatedReportShowNode.text();
      const formattedDate = formatDateTime(updatedReport.updatedAt);

      expect(renderedText).toContain(formattedDate);
    });
  });

  describe('when the report\'s updatedAt value is equal to it\'s createdAt value', () => {
    it('contains the createdAt/updatedAt value exactly once', () => {
      const renderedText = reportShowNode.text();
      const formattedDate = formatDate(report.createdAt);

      expect(report.createdAt).toEqual(report.updatedAt);
      expect(renderedText).toContain(formattedDate);
      const replacedText = renderedText.replace(formattedDate, '');
      expect(replacedText).not.toContain(formattedDate);
    });
  });

  it('contains the report improvement text', () => {
    const renderedText = reportShowNode.text();

    expect(renderedText).toContain(report.improvement);
  });

  it('has a Link that links to the report index page', () => {
   const indexLink = reportShowNode.find('Link');

   expect(indexLink.node.props.to).toEqual(`/`);
  });
});
