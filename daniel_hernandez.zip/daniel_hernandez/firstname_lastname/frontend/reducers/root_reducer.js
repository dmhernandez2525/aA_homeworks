import ReportsReducer from './reports_reducer';
import { combineReducers } from 'redux';


const RootReducer = combineReducers({
    reports: ReportsReducer
})


export default RootReducer
