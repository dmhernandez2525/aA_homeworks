import merge from 'lodash/merge';

import {
  RECEIVE_REPORTS,
  RECEIVE_REPORT,
  REMOVE_REPORT,
} from '../actions/report_actions';

const ReportsReducer = (state ={}, action) => {
  Object.freeze(state)
  switch (action.type) {
    case RECEIVE_REPORTS:
      return action.reports;
    case RECEIVE_REPORT:
      return Object.assign({}, state, {
        [action.report.id]: action.report
      });
    case REMOVE_REPORT:
      let newState = Object.assign({}, state)
      delete newState[action.reportId]
      return newState;
  
    default:
      return state;
  }

};

export default ReportsReducer;
