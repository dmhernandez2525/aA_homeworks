import * as ReportAPIUtil from '../util/report_api_util';

      export const RECEIVE_REPORTS = "RECEIVE_REPORTS";
      export const RECEIVE_REPORT = "RECEIVE_REPORT";
      export const REMOVE_REPORT = "REMOVE_REPORT";
      
         export const requestReports = (report) => (dispatch) => (
             ReportAPIUtil.fetchReports(report).then(reports => dispatch({
                 type: RECEIVE_REPORTS,
                 reports
             }))
         )
        
      
         export const requestReport = (report) => (dispatch) => (
             ReportAPIUtil.fetchReport(report).then(report => dispatch({
                 type: RECEIVE_REPORT,
                 report
             }))
         )
        
      
         export const createReport = (report) => (dispatch) => (
             ReportAPIUtil.createReport(report).then(report => dispatch({type:RECEIVE_REPORT, report}))
         )
        
      
         export const updateReport = (report) => (dispatch) => (
             ReportAPIUtil.updateReport(report).then(report => dispatch({type:RECEIVE_REPORT, report}))
         )
        
      
         export const deleteReport = (report) => (dispatch) => (
             ReportAPIUtil.deleteReport(report).then(report => dispatch({type:REMOVE_REPORT, reportId:report}))
         )
        