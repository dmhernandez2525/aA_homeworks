import React from 'react';
import { Link, withRouter } from 'react-router-dom';

import { formatDate } from '../../util/date_util';


// Use the `formatDate` function to display `createdAt` in this component. Like
// this: `formatDate(report.createdAt)`.

const ReportIndexItem = ({ report, deleteReport}) => {
    return(
        <div>
        <Link to={`/reports/${report.id}`}>{formatDate(report.createdAt)}</Link>
        <Link to={`/reports/${report.id}/edit`}>Edit</Link>
        <button onClick={() => deleteReport(report.id)}>delete</button>
        </div>
    )

};

export default withRouter(ReportIndexItem);
