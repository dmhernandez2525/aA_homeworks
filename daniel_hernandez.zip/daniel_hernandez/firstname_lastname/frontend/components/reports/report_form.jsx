import React from 'react';
import { withRouter } from 'react-router-dom';

class ReportForm extends React.Component {
  constructor(props){
    super(props)
    this.state = this.props.report
    this.handleSuibmit = this.handleSuibmit.bind(this)
  }
  handleSuibmit(e){
    e.preventDefault
    this.props.action(this.state)
  }
  render() {
    return (
      <div>
        <form onSubmit={this.handleSuibmit}>
          <textarea value={this.state.improvement} onChange={e => this.setState({ improvement: e.target.value})}/>
          <input type="text" value={this.state.understanding} onChange={e => this.setState({ understanding: e.target.value})}/>
        </form>
      </div>
    );
  }
}

export default withRouter(ReportForm);
