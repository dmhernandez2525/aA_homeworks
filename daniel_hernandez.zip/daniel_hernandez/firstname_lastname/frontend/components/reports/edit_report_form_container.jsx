import React from 'react';
import { connect } from 'react-redux';
import { requestReport, updateReport } from '../../actions/report_actions';
import ReportForm from './report_form';


class EditReportForm extends React.Component {
  componentDidMount(){
    this.props.requestReport()
  }

  render() {
    const { action, formType, report } = this.props;
    return (
      <ReportForm
        action={action}
        formType={formType}
        report={report} />
    );
  }
}

const msp = (state, ownProps) => {
  let report = state.reports[ownProps.match.params.reportId]
  return ({
    report

  })
};
const mdp = (dispatch, ownProps) => {
  return ({
    action: (report) => dispatch(updateReport(report)),
    requestReport: () => dispatch(requestReport(ownProps.match.params.reportId))

  })
};


export default connect(msp, mdp)(EditReportForm)