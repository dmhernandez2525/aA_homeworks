import React from 'react';
import { Link } from 'react-router-dom';

import ReportIndexItem from './report_index_item';

class ReportIndex extends React.Component {
  componentDidMount() {
    this.props.requestReports();
  }

  render() {
    let allPosts = this.props.reports.map(report => <ReportIndexItem key={report.id} report={report} deleteReport={this.props.deleteReport}/>)
    return (
      <div>
        <ul>
        {allPosts}
        </ul>
        <Link to="/reports/new">make new report</Link>
      </div>
    );
  }
}

export default ReportIndex;
