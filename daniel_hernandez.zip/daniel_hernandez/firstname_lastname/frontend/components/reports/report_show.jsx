import React from 'react';
import { Link } from 'react-router-dom';

import {
  formatDate,
  formatTime,
  formatDateTime
} from '../../util/date_util';


// Display the date of the `createdAt` property like this:
// `formatDate(this.props.report.createdAt)`.

// Display the time of the `createdAt` property like this:
// `formatTime(this.props.report.createdAt)`.

// If `createdAt` is not equivalent to `updatedAt`, display `updatedAt`
// like this: `formatDateTime(this.props.report.updatedAt)`.

class ReportShow extends React.Component {
  componentDidMount(){
    this.props.requestReport()
  }
  render() {
    if (this.props.report.createdAt === this.props.report.updatedAt) {
      return(
        <div>
          {formatDate(this.props.report.createdAt)}
          {formatTime(this.props.report.createdAt)}
          {this.props.report.improvement}

          <Link to="/" ></Link>
        </div>
      )
    }
    return (
      <div>
        {formatDate(this.props.report.createdAt)}
        {formatTime(this.props.report.createdAt)}
        {formatDateTime(this.props.report.updatedAt)}
        {this.props.report.improvement}


        <Link to="/" ></Link>
      </div>
    );
  }
}

export default ReportShow;
