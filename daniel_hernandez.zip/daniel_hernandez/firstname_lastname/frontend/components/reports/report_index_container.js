import { connect } from 'react-redux';

import ReportIndex from './report_index';
import {
  requestReports,
  deleteReport
} from '../../actions/report_actions';

const msp = (state, ownProps) => {
  let reports = Object.values(state.reports)
  return ({
    reports
  })
};
const mdp = (dispatch, ownProps) => {
  return ({
    requestReports: (id) => dispatch(requestReports(id)),
    deleteReport: (id) => dispatch(deleteReport(id))

  })
};


export default connect(msp, mdp)(ReportIndex)