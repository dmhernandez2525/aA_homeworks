import { connect } from 'react-redux';
import { createReport } from '../../actions/report_actions';
import ReportForm from './report_form';

const msp = (state ,ownProps) => {
    return({
        report: {
            understanding: '',
            improvement: ''
        }

    })
};
const mdp = (dispatch ,ownProps) => {
    return({
        action: (report) => dispatch(createReport(report))
    })
};


export default connect(msp, mdp)(ReportForm)