import React from 'react';
import { connect } from 'react-redux';

import ReportShow from './report_show';
import { requestReport } from '../../actions/report_actions';

const msp = (state, ownProps) => {
    let report = state.reports[ownProps.match.params.reportId]
    return ({
        report

    })
};
const mdp = (dispatch, ownProps) => {
    return ({
        requestReport: () => dispatch(requestReport(ownProps.match.params.reportId))

    })
};


export default connect(msp, mdp)(ReportShow)