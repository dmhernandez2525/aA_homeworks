# require_relative "board"
# require_relative "human_player"
# require_relative "computer_player"
require_relative "game"

game = Game.new
while !game.board.over?
    game.