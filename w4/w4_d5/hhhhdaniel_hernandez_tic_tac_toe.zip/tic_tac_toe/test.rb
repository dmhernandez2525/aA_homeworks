


def evaluate(str)
    str.each_char.with_index do |char, i|
        if char == "*"
            num1 = str[0...i]
            num2 = str[i + 1..str.length]
            return num1.to_i * num2.to_i
        elsif char == "/"
            num1 = str[0...i]
            num2 = str[i + 1..str.length]
            return num1.to_i / num2.to_i
        elsif char == "+"
            num1 = str[0...i]
            num2 = str[i + 1..str.length]
            return num1.to_i + num2.to_i
         elsif char == "-"
            num1 = str[0...i]
            num2 = str[i + 1..str.length]
            return num1.to_i - num2.to_i
        end
    end
    return str.to_i
end

p evaluate("5")         # => 5
p evaluate("555")       # => 555
p evaluate("5+5")       # => 10
p evaluate("46-40")     # => 6
p evaluate("10*10")     # => 100
p evaluate("100/10")    # => 10





#### Math Eval ####
# Eval is a function that takes a string and executes it as code. This
# can be very complicated to implement, so you will only need to
# implement a small subset.
#
# Write a function math_eval that takes a string and evaluates single-digit
# numbers as well as the 4 basic arithmetic functions ( + - * / ). Do not worry about
# parentheses or order of operations. Just evaluate everything from left
# to right. You may also assume that you will be given syntactically
# correct statements with no spaces or extra characters.
#
# Constraint: You may not call eval or any similar function.
#
# Examples:
# math_eval('5') => 5
# math_eval('5+5') => 10
# math_eval('1+2*3') => 9
#
# Bonus: If you have extra time, support double-digit numbers.
# math_eval('10*2/5+16') => 20


def math_eval(string)
    arr = string.split("")
    num_bank = ("0" .. "9")
    total = arr[0].to_i
    
    arr.each_with_index do |char, index|
        unless num_bank.include?(char)
            arr_for_reduce = [total,arr[index+1].to_i]
            total = arr_for_reduce.reduce(char)
        end
    end
    total
end

# p math_eval('5') #=> 5
# p math_eval('5+5') #=> 10
# p math_eval('1+2*3') #=> 9
# p math_eval('10*2/5+16') #=> 20